# API REST Slim CRUD
Projeto exemplo com Slim, PDO, CRUD e SOLID.